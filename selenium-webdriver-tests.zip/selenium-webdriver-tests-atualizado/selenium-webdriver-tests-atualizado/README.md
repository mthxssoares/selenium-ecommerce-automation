# Selenium WebDriver Tests

![Selenium](https://img.shields.io/badge/Selenium-43B02A?style=for-the-badge&logo=selenium&logoColor=white)
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![Cucumber](https://img.shields.io/badge/Cucumber-23D96C?style=for-the-badge&logo=cucumber&logoColor=white)
![JUnit](https://img.shields.io/badge/JUnit-25A162?style=for-the-badge&logo=junit5&logoColor=white)
![Maven](https://img.shields.io/badge/Maven-C71A36?style=for-the-badge&logo=apachemaven&logoColor=white)

Projeto de automação de testes web com foco principal em **Selenium WebDriver**, utilizando **Java**, **Cucumber**, **JUnit** e **Maven**.

O projeto valida fluxos web no site de prática da QAzando, com cenários escritos em **Gherkin**, execução com **Cucumber + JUnit** e geração de relatório em JSON/HTML, incluindo suporte para relatório formatado com **Cluecumber**.

---

## Objetivo do projeto

O objetivo deste projeto é praticar automação de testes web com **Selenium WebDriver**, utilizando uma estrutura organizada e atualizada para projetos Java modernos.

Principais objetivos:

* Automatizar fluxos web com Selenium;
* Escrever cenários de teste em Gherkin;
* Executar testes com Cucumber e JUnit;
* Gerenciar dependências com Maven;
* Organizar código com separação entre pages, steps, runner e support;
* Gerar relatórios de execução dos testes.

---

## Tecnologias utilizadas

* Selenium WebDriver
* Java 26
* Maven
* Cucumber 7
* JUnit 4
* Gherkin
* ChromeDriver via Selenium Manager
* Cluecumber Report
* Git
* GitHub

---

## Funcionalidades automatizadas

### Cadastro de usuário

* Acessar a tela de cadastro;
* Preencher os campos obrigatórios;
* Clicar em cadastrar;
* Validar a mensagem de cadastro realizado com sucesso.

### Login de usuário

* Acessar a tela de login;
* Preencher e-mail e senha;
* Clicar em Login;
* Validar a mensagem de login realizado com sucesso.

---

## Cenário de cadastro

```gherkin
# language: pt

@cadastro_de_usuario
Funcionalidade: Cadastro de usuário
  Eu como usuário do sistema
  Quero me cadastrar
  Para finalizar uma compra no site

  @cadastro_usuario_sucesso
  Cenário: Cadastro de usuário com sucesso
    Dado que estou na tela de cadastro de usuário
    E preencho todos os campos obrigatórios
    Quando clico em cadastrar
    Então vejo mensagem de usuário cadastrado com sucesso
```

---

## Pré-requisitos

Antes de executar o projeto, é necessário ter instalado:

* Java 26 ou versão compatível com o projeto;
* Maven configurado no PATH;
* Google Chrome instalado;
* Git instalado;
* IDE de sua preferência, como IntelliJ IDEA ou VS Code.

> Caso o comando `mvn` não seja reconhecido no terminal, instale o Maven e configure o PATH do Windows.

---

## Como executar o projeto

Após baixar ou clonar o repositório, acesse a pasta raiz do projeto, onde está localizado o arquivo `pom.xml`.

Com o terminal aberto na raiz do projeto, execute:

```bash
mvn clean test
```

Para executar uma tag específica:

```bash
mvn test -Dcucumber.filter.tags="@cadastro_usuario_sucesso"
```

Para gerar o relatório Cluecumber:

```bash
mvn clean test cluecumber-report:reporting
```

O relatório será gerado em:

```text
target/cluecumber-report/index.html
```

---

## Executando pela IDE

Também é possível executar o projeto diretamente pela IDE.

No IntelliJ IDEA, abra a classe runner localizada em:

```text
src/test/java/runner/RunCucumber.java
```

Depois, execute a classe `RunCucumber`.

---

## Relatórios

Durante a execução, o Cucumber gera relatórios em:

```text
target/reports/cucumberTests.json
target/reports/cucumber-html-report.html
```

Após executar o Cluecumber, o relatório formatado será gerado em:

```text
target/cluecumber-report/index.html
```

---

## Boas práticas aplicadas

* Atualização para Selenium 4;
* Atualização para Cucumber 7;
* Uso do Selenium WebDriver como ferramenta principal de automação web;
* Separação entre cenários, steps, pages, runner e support;
* Escrita de cenários em Gherkin;
* Uso de tags para organizar a execução;
* Uso de massa dinâmica para cadastro de usuário;
* Uso de Maven para gerenciamento de dependências;
* Estrutura limpa para versionamento no GitHub.

---

## Observação sobre arquivos no GitHub

Não é necessário subir arquivos gerados automaticamente ou internos da IDE, como:

```text
target/
.idea/
*.iml
```

O `.gitignore` já foi ajustado para ignorar esses arquivos.

---

## Status do projeto

Projeto em atualização e evolução contínua.

---

## Autor

**Matheus Soares**

QA Enthusiast | Software Testing | Selenium | Java | Cucumber | Maven
