package steps;

import io.cucumber.java.pt.Então;
import io.cucumber.java.pt.Quando;
import pages.CompraPage;

public class CompraSteps {

    CompraPage compraPage = new CompraPage();

    @Quando("acesso a lista de produtos")
    public void acesso_a_lista_de_produtos() {
        compraPage.acessarListaProdutos();
    }

    @Quando("seleciono um produto")
    public void seleciono_um_produto() {
        compraPage.selecionarProduto();
    }

    @Quando("adiciono o produto ao carrinho")
    public void adiciono_o_produto_ao_carrinho() {
        compraPage.adicionarProdutoAoCarrinho();
    }

    @Quando("finalizo a compra")
    public void finalizo_a_compra() {
        compraPage.finalizarCompra();
    }

    @Então("vejo mensagem de compra realizada com sucesso")
    public void vejo_mensagem_de_compra_realizada_com_sucesso() {
        compraPage.validarCompraRealizadaComSucesso();
    }

    @Então("vejo o produto no carrinho")
    public void vejo_o_produto_no_carrinho() {
        compraPage.validarProdutoNoCarrinho();
    }
}