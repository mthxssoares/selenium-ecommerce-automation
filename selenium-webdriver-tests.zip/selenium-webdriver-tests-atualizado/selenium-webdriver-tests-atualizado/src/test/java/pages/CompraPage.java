package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import support.Commands;

public class CompraPage extends Commands {

    private By produto = By.xpath("//*[contains(text(),'Produto')]");
    private By botaoAdicionarCarrinho = By.xpath("//*[contains(text(),'Adicionar')]");
    private By botaoCarrinho = By.xpath("//*[contains(text(),'Carrinho')]");
    private By botaoFinalizarCompra = By.xpath("//*[contains(text(),'Finalizar')]");
    private By mensagemCompraSucesso = By.xpath("//*[contains(text(),'Compra realizada')]");
    private By produtoNoCarrinho = By.xpath("//*[contains(text(),'Produto')]");

    public void acessarListaProdutos() {
        System.out.println("Acessando lista de produtos");

        /*
         * Se após o login a aplicação já abrir direto na tela de produtos,
         * não precisa clicar em nada aqui.
         *
         * Se existir um menu ou botão chamado Produtos, crie o elemento e clique nele.
         */
    }

    public void selecionarProduto() {
        clickElement(produto);
    }

    public void adicionarProdutoAoCarrinho() {
        clickElement(botaoAdicionarCarrinho);
    }

    public void finalizarCompra() {
        clickElement(botaoCarrinho);
        clickElement(botaoFinalizarCompra);
    }

    public void validarCompraRealizadaComSucesso() {
        waitElementBeClickable(mensagemCompraSucesso, 10);

        String mensagemAtual = getDriver().findElement(mensagemCompraSucesso).getText();

        Assert.assertTrue(
                "Mensagem de compra realizada não foi exibida.",
                mensagemAtual.contains("Compra realizada")
        );
    }

    public void validarProdutoNoCarrinho() {
        clickElement(botaoCarrinho);
        waitElementBeClickable(produtoNoCarrinho, 10);

        Assert.assertTrue(
                "Produto não foi exibido no carrinho.",
                getDriver().findElement(produtoNoCarrinho).isDisplayed()
        );
    }
}