package runner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.AfterClass;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = "src/test/resources/features",
        glue = {"steps"},
        tags = "@compra ",
        plugin = {
                "pretty",
                "json:target/reports/cucumberTests.json",
                "html:target/reports/cucumber-html-report.html"
        },
        monochrome = true
)
public class RunCucumber extends RunBase {

    @AfterClass
    public static void stop() {
        if (getDriver() != null) {
            getDriver().quit();
        }
    }
}
