package support;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import runner.RunCucumber;

import java.time.Duration;

public class Commands extends RunCucumber {

    public static void waitElementBeClickable(By element, Integer tempo) {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(tempo));
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public static void waitElementBeVisible(By element, Integer tempo) {
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(tempo));
        wait.until(ExpectedConditions.visibilityOfElementLocated(element));
    }

    public static void clickElement(By element) {
        System.out.println("##############################################");

        try {
            System.out.println("******** Vai clicar no elemento: " + element);

            waitElementBeClickable(element, 10);
            getDriver().findElement(element).click();

            System.out.println("******* Clicou no elemento: " + element);
        } catch (Exception error) {
            System.out.println("********* Aconteceu um erro ao clicar no elemento: " + element);
            System.out.println(error);
        }

        System.out.println("##############################################");
    }

    public static void fillField(By element, String valor) {
        System.out.println("##############################################");

        try {
            System.out.println("******** Vai preencher o elemento: " + element);
            waitElementBeVisible(element, 10);
            getDriver().findElement(element).sendKeys(valor);
            System.out.println("******* Preencheu o elemento: " + element);
        } catch (Exception error) {
            System.out.println("********* Aconteceu um erro ao preencher o campo: " + element);
            System.out.println(error);
        }

        System.out.println("##############################################");
    }

    public static void checkMessage(By element, String expectedMessage){
        String actualMessage = "";
        System.out.println("##############################################");

        try {
            System.out.println("******** Vai validar mensagem: " + expectedMessage);
            waitElementBeVisible(element, 10);
            actualMessage = getDriver().findElement(element).getText();
            Assert.assertEquals(expectedMessage, actualMessage);
            System.out.println("******** Validou mensagem: " + expectedMessage);

        }catch (Exception error){
            System.out.println("******* Aconteceu um erro validar mensagem " + expectedMessage);
            System.out.println("******* Mensagem esperada" + actualMessage);
            System.out.println("******* Mensagem atual" + actualMessage);
            System.out.println(error);

        }


        System.out.println("##############################################");
    }
}