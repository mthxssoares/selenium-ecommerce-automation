package support;

import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import runner.RunCucumber;

import java.time.Duration;
import java.util.Random;

public class Utils extends RunCucumber {


    public static String getRandomEmail() {
        String emailInicial = "qazando_";
        String emailFinal = "@qazando.com.br";

        Random random = new Random();
        int numeroAleatorio = random.nextInt(999999999);

        return emailInicial + numeroAleatorio + emailFinal;
    }
}
