# language: pt

@compra
Funcionalidade: Compra de produto
  Eu como usuário logado
  Quero selecionar um produto
  Para realizar uma compra no site

  Contexto: Usuário logado na aplicação
    Dado que estou logado na aplicação com user "matheus.finotti@qazando.com" e senha "123456"

  @compra-sucesso
  Cenário: Compra realizada com sucesso
    Quando acesso a lista de produtos
    E seleciono um produto
    E adiciono o produto ao carrinho
    E finalizo a compra
    Então vejo mensagem de compra realizada com sucesso

  @produto-carrinho
  Cenário: Validar produto adicionado ao carrinho
    Quando acesso a lista de produtos
    E seleciono um produto
    E adiciono o produto ao carrinho
    Então vejo o produto no carrinho