# language: pt

  @login
  Funcionalidade: Login
    Eu como usuário do sistema
    Quero fazer login
    Para fazer uma compra no site

    Contexto: Acessar tela de Login
      Dado que estou na tela de login

    @login-sucesso
    Cenário: Login com sucesso
      Quando preencho login "matheus.finotti@qazando.com" e senha "123456"
      E clico em Login
      Então vejo mensagem de login com sucesso

    @login-invalido
    Esquema do Cenario: Validar "<name>"
      Quando  preencho login "<user>" e senha "<password>"
      E clico em Login
      Então vejo mensagem "<message>" de campo não preenchido

      Exemplos:
        | user                        | password | message          | name            |
        | matheus.finotti.com         | 123456   | E-mail inválido. | E-mail inválido |
        |                             | 123456   | E-mail inválido. | E-mail vazio    |
        | matheus.finotti@qazando.com | 374554   | Senha inválida.  | Senha inválido  |
        | matheus.finotti@qazando.com |          | Senha inválida.  | Senha Vazia     |


